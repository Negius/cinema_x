import 'dart:convert';
import 'dart:math';

import 'package:cinema_x/models/Movie.dart';
import 'package:cinema_x/models/hall.dart';
import 'package:cinema_x/models/palette.dart';
import 'package:cinema_x/screens/booking/onePageCheckout.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class SeatSelection extends StatefulWidget {
  SeatSelection({
    this.movie,
    this.planId,
    this.dateTimeFull,
    Key key,
  }) : super(key: key);
  final Movie movie;
  final int planId;
  final DateTime dateTimeFull;
  @override
  _SeatSelectionState createState() {
    return _SeatSelectionState();
  }
}

class _SeatSelectionState extends State<SeatSelection> {
  double seatSize = 26;

  List<Map> seatSelected = [];
  List<Map> list = [];
  Future<List<List<Map>>> test;
  ScrollController scrollController;
  bool canLoad = true;
  int numOfRows = 1;
  int numOfColumns = 1;
  Future<List<Map>> _seatMap;
  @override
  void initState() {
    _seatMap = getSeatInfo();

    super.initState();
  }

  Future<List<Map>> getSeatInfo() async {
    try {
      List<List<Map>> seats = await fetchApiSeats(widget.planId as int);
      numOfRows = seats.length;
      numOfColumns = seats.map((r) => r.length).toList().reduce(max);
      List<Map> result = [];
      seats.forEach((row) {
        row.forEach((seat) {
          result.add(seat);
        });
      });
      return result;
    } on Exception catch (error) {
      canLoad = false;
      throw (error);
    }
  }

  String addS(value) {
    return value > 1 ? "s" : "";
  }

  double scale = 1;
  double previousScale = 1;
  double startScale = 1;
  double currentSize;

  @override
  Widget build(BuildContext context) {
    double width =
        ((MediaQuery.of(context).size.width - 64) / numOfColumns < seatSize
                ? seatSize * numOfColumns + 64
                : MediaQuery.of(context).size.width) *
            scale;

    double seatLayoutWidth = width - 32;

    currentSize = (seatLayoutWidth) / numOfColumns;
    if (scrollController == null)
      scrollController = new ScrollController(
          initialScrollOffset: (width - MediaQuery.of(context).size.width) / 2);
    return Scaffold(
//      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        title: Text("Chọn vị trí ngồi"),
        elevation: 0,
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        child: Stack(
          children: <Widget>[
            Container(
              height: 60,
            ),
            GestureDetector(
              onScaleStart: (s) {
                setState(() {
                  startScale = scale;
                });
              },
              onScaleUpdate: (scaleDetails) {
                double newScale = startScale * scaleDetails.scale;
                if (newScale >= 1)
                  setState(() {
                    scale = newScale;
                  });
              },
              onScaleEnd: (s) {},
              child: LayoutBuilder(
                builder: (context, constraint) => SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  controller: scrollController,
                  child: Container(
                    child: SizedBox(
                      width: seatLayoutWidth,
                      child: SingleChildScrollView(
                        child: LayoutBuilder(
                          builder: (context, constraints) => Column(
                            children: <Widget>[
                              Container(
                                height: 20,
                              ),
                              Container(
                                padding: EdgeInsets.only(bottom: 12),
                                width: constraints.maxWidth,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(
                                            color: Palette.getContrastColor(
                                                    context)
                                                .withOpacity(0.3),
                                            width: 2))),
                                child: Text(
                                  "MÀN HÌNH",
                                  style: Theme.of(context)
                                      .textTheme
                                      .subhead
                                      .copyWith(
                                          fontSize: Theme.of(context)
                                                  .textTheme
                                                  .subhead
                                                  .fontSize *
                                              scale,
                                          color:
                                              Palette.getContrastColor(context),
                                          fontWeight: FontWeight.w700),
                                ),
                              ),
                              Container(
                                height: 40,
                              ),
                              Container(
                                padding: EdgeInsets.only(left: 16, right: 16),
                                child: buildSeatLayout(context, constraints),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(bottom: 0, child: buildInfoLayout(context))
          ],
        ),
      ),
    );
  }

  buildSeatLayout(BuildContext context, BoxConstraints constraints) {
    return FutureBuilder(
        future: _seatMap,
        builder: (context, snapshot) {
          if (snapshot.hasData)
            return Container(
              height: currentSize * numOfRows + 24,
              child: GridView.count(
                physics: NeverScrollableScrollPhysics(),
                crossAxisCount: numOfColumns,
                children: snapshot.data.map<Widget>((item) {
                  int type = item["type"];
                  int status = item["status"];
                  String label = item["label"];
                  bool isSelected = seatSelected.contains(item);
                  return GestureDetector(
                    onTap: status == 0
                        ? () {
                            seatSelect(item);
                          }
                        : () {},
                    child: Container(
                      width: seatSize,
                      height: seatSize,
                      alignment: Alignment.center,
                      margin: EdgeInsets.all(2),
                      decoration: type != 12
                          ? BoxDecoration(
                              color: isSelected
                                  ? Theme.of(context).accentColor
                                  : status != 0
                                      ? Color(0xFFdbd7cc)
                                      : type == 0
                                          ? Color(0xFFab9c90)
                                          : type == 1
                                              ? Color(0xFF914453)
                                              : Colors.pink,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(4)),
                              border: Border.all(
                                color: Palette.getContrastColor(context)
                                    .withOpacity(0.5),
                              ),
                            )
                          : null,
                      child: type != 12
                          ? FittedBox(
                              fit: BoxFit.fill,
                              child: status == 0
                                  ? Text(
                                      label,
                                      style: TextStyle(
                                        fontSize: seatSize * .5,
                                        color: Colors.white,
                                      ),
                                    )
                                  : Icon(Icons.close, color: Colors.white),
                            )
                          : null,
                    ),
                  );
                }).toList(),
              ),
            );
          else
            return Container();
        });
  }

  void seatSelect(Map<dynamic, dynamic> seat) {
    setState(() {
      if (seatSelected.contains(seat)) {
        seatSelected.remove(seat);
      } else
        seatSelected.add(seat);
    });
  }

  buildInfoLayout(BuildContext context) {
    return Hero(
      tag: "payment",
      child: Card(
        clipBehavior: Clip.hardEdge,
        margin: EdgeInsets.all(0),
        elevation: 6,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(0))),
        child: Container(
          color: Theme.of(context).brightness == Brightness.dark
              ? Colors.black
              : Colors.white,
          height: 120,
          padding: EdgeInsets.only(bottom: 24, top: 24, left: 24, right: 24),
          width: MediaQuery.of(context).size.width,
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                  alignment: Alignment.topLeft,
                  child: Column(
                    children: <Widget>[
                      Text(
                        "Số ghế đã chọn: ${seatSelected.length}",
                        style: Theme.of(context)
                            .textTheme
                            .subtitle
                            .copyWith(fontWeight: FontWeight.w700),
                      ),
                      Expanded(
                        flex: 1,
                        child: Text(
                          "Danh sách ghế: ${seatSelected.map((s) => s["label"]).join(", ")}",
                          style: Theme.of(context)
                              .textTheme
                              .subtitle
                              .copyWith(fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  ),
                ),
                flex: 1,
              ),
              GestureDetector(
                onTap: () {
                  setState(() {
                    testPayment(context);
                  });
                },
                child: Container(
                  height: 30,
                  width: 100,
                  alignment: Alignment.center,
                  child: Text(
                    "Thanh toán",
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  decoration: const BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    gradient: LinearGradient(
                      colors: <Color>[
                        Color(0xFF0D47A1),
                        Color(0xFF1976D2),
                        Color(0xFF42A5F5),
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  void testPayment(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    print(seatSelected[0]);
    var listChairValueF1 = seatSelected.map((s) => s["label"]).join(", ");
    var seatsF1 = seatSelected.map((s) => s["seat"]).join(", ");
    String api = "http://testapi.chieuphimquocgia.com.vn/api/CreateOrder";

    Map<String, String> headers = {
      'Content-type': 'application/json',
      'Accept': 'application/json'
    };

    var body = {
      "customerId": prefs.getInt("customerId") ?? 0,
      "planScreenId": widget.planId ?? 0,
      "seatsF1": seatsF1,
      "ListChairValueF1": listChairValueF1,
      "CustomerFirstName": prefs.getString("firstName") ?? "",
      "CustomerLastName": prefs.getString("lastName") ?? "",
      "CustomerEmail": prefs.getString("email") ?? "",
      "CustomerPhone": prefs.getString("phone") ?? "",
      "PaymentMethodSystemName": "VNPAY"
    };
    print(body);
    var response = await http.post(Uri.parse(api),
        headers: headers, body: json.encode(body));
    print(response.statusCode);
    print(response.body);
    var parsed = json.decode(response.body);
    var orderId = parsed["OrderId"];
    var total = (parsed["OrderTotal"] as double).toInt() ?? 0;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CheckoutPage(
          movie: widget.movie,
          projectDateTime: widget.dateTimeFull,
          orderId: orderId,
          total: total,
          label: listChairValueF1,
        ),
      ),
    );
  }
}
