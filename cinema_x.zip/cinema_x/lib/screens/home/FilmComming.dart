import 'package:flutter/material.dart';

class Comming extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return new Container(
      child: new Center(
        child: new Icon(Icons.directions_transit),
      ),
    );

  }
}