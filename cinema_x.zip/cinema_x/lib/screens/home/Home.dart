import 'dart:io';

import 'package:carousel_pro/carousel_pro.dart';
import 'package:cinema_x/utils/menu_drawer.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import './FilmComming.dart' as Fcomming;
import './FilmShowing.dart' as Fshowing;

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  final List imgList = [
    'https://chieuphimquocgia.com.vn/Themes/RapChieuPhim/Content/content.v2/images/ch%e1%bb%8b%20ch%E1%BB%8B%20em%20em.jpg',
    'https://chieuphimquocgia.com.vn/Themes/RapChieuPhim/Content/content.v2/images/1jumanji.jpg',
    'https://chieuphimquocgia.com.vn/Themes/RapChieuPhim/Content/content.v2/images/2m%e1%ba%aft%20bi%E1%BA%BFc.jpg',
    'https://chieuphimquocgia.com.vn/Themes/RapChieuPhim/Content/content.v2/images/1.anh%20trai%20y%C3%AAu%20qu%C3%A1i.jpg',
    'https://chieuphimquocgia.com.vn/Themes/RapChieuPhim/Content/content.v2/images/2.%20FROZEN.jpg',
  ];

  final List imgSlider = [
    'https://chieuphimquocgia.com.vn/Themes/RapChieuPhim/Content/content.v2/images/ch%e1%bb%8b%20ch%E1%BB%8B%20em%20em.jpg',
    'https://chieuphimquocgia.com.vn/Themes/RapChieuPhim/Content/content.v2/images/1jumanji.jpg',
    'https://chieuphimquocgia.com.vn/Themes/RapChieuPhim/Content/content.v2/images/2m%e1%ba%aft%20bi%E1%BA%BFc.jpg',
    'https://chieuphimquocgia.com.vn/Themes/RapChieuPhim/Content/content.v2/images/1.anh%20trai%20y%C3%AAu%20qu%C3%A1i.jpg',
    'https://chieuphimquocgia.com.vn/Themes/RapChieuPhim/Content/content.v2/images/2.%20FROZEN.jpg',
  ];
  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((prefs) {
      bool isLoggedIn = prefs.getBool("isLoggedIn") ?? false;
      prefs.setBool("isLoggedIn", isLoggedIn);
    });
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      endDrawer: MenuBar(),
      key: _scaffoldKey,
      body: Stack(
        children: <Widget>[
          Container(
            height: double.infinity,
            width: double.infinity,
            child: ListView(children: <Widget>[
              imageSliderCarousel(),
              tabFilms(),
              tabNews(),
            ]),
          ),
          new Positioned(
            top: 0.0,
            left: 0.0,
            right: 0.0,
            child: AppBar(
              backgroundColor: Colors.transparent,
              leading: IconButton(
                icon: Icon(Icons.arrow_back),
                onPressed: () => exit(0),
              ),
              actions: <Widget>[
                IconButton(
                  icon: Icon(Icons.menu),
                  onPressed: () => _scaffoldKey.currentState.openEndDrawer(),
                ),
              ],
            ),
          ),
        ],
      ),
      //)
    );
  }

  Widget imageSliderCarousel() {
    return Container(
      height: 135,
      child: Carousel(
        dotSize: 0.0,
        boxFit: BoxFit.cover,
        images: imgSlider.map((img) => Image.network(img)).toList(),
        autoplay: true,
        indicatorBgPadding: 0.0,
      ),
    );
  }

  Widget tabFilms() {
    return Container(
      height: 510,
      color: Colors.brown,
      child: DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(50),
            child: AppBar(
              backgroundColor: Colors.red,
              //height: 700,
              bottom: TabBar(
                tabs: [
                  Tab(
                    text: 'ĐANG CHIẾU',
                  ),
                  Tab(
                    text: 'SẮP CHIẾU',
                  ),
                  Tab(
                    text: 'LIÊN HOAN',
                  ),
                ],
              ),
            ),
          ),
          body: new TabBarView(
            children: <Widget>[
              new Fshowing.Showing(),
              new Fcomming.Comming(),
              Icon(Icons.directions_bike),
            ],
          ),
        ),
      ),
    );
  }

  Widget tabNews() {
    return Container(
      height: 570,
      color: Colors.brown,
      child: DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: new AppBar(
            backgroundColor: Colors.red,
            title: new Text("Tin Tức"),
          ),
          body: new ListView(
            children: <Widget>[
              Icon(Icons.directions_car),
              Icon(Icons.directions_transit),
              Icon(Icons.directions_bike),
            ],
          ),
        ),
      ),
    );
  }
}
