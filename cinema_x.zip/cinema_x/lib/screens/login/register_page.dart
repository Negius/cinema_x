import 'package:cinema_x/utils/menu_drawer.dart';
import 'package:flutter/material.dart';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  String _userId;
  String _password;
  String _rePassword;
  String _email;
  String _phone;
  String _firstName;
  String _lastName;
  String _address;

  bool _autoValidate = false;
  bool _showPass = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      endDrawer: MenuBar(),
      key: _scaffoldKey,
      appBar: new AppBar(
        title: new Text('Đăng ký tài khoản'),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.menu),
            onPressed: () => _scaffoldKey.currentState.openEndDrawer(),
          ),
        ],
        backgroundColor: Colors.red,
      ),
      //  resizeToAvoidBottomPadding: false,
      body: Container(
        padding: EdgeInsets.fromLTRB(30, 0, 30, 0),
        constraints: BoxConstraints.expand(),
        color: Colors.white,
        child: Form(
          key: _formKey,
          autovalidate: _autoValidate,
          child: ListView(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 80),
                child: Container(
                  width: 70,
                  height: 70,
                  padding: EdgeInsets.all(15),
                  child: Image.asset("assets/images/logo_home.png"),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 40),
                child: TextFormField(
                  validator: (value) {
                    final _errors = [
                      "Tên đăng nhập không được để trống",
                      "Tên đăng nhập phải dài từ 6-15 ký tự",
                      "Tên đăng nhập không được chứa ký tự đặc biệt"
                    ];
                    return value == null
                        ? _errors[0]
                        : (value.length < 6 || value.length > 15)
                            ? _errors[1]
                            : null;
                  },
                  onSaved: (value) => _userId = value,
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                  ),
                  decoration: InputDecoration(
                    labelText: "Tên đăng nhập",
                    labelStyle:
                        new TextStyle(color: Colors.black26, fontSize: 15),
                    focusedBorder: new UnderlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.red,
                          width: 1.0,
                          style: BorderStyle.solid),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 40),
                child: TextFormField(
                  onSaved: (value) => _password = value,
                  style: TextStyle(fontSize: 20, color: Colors.black),
                  obscureText: !_showPass,
                  validator: (value) {
                    final _errors1 = ["Mật khẩu không được để trống", ""];
                    return value == null ? _errors1[0] : null;
                  },
                  decoration: InputDecoration(
                    labelText: "Mật khẩu",
                    labelStyle: TextStyle(color: Colors.black26, fontSize: 15),
                    focusedBorder: new UnderlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.red,
                          width: 1.0,
                          style: BorderStyle.solid),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 40),
                child: TextFormField(
                  onSaved: (value) => _rePassword = value,
                  style: TextStyle(fontSize: 20, color: Colors.black),
                  obscureText: !_showPass,
                  decoration: InputDecoration(
                    labelText: "Nhập lại mật khẩu",
                    labelStyle: TextStyle(color: Colors.black26, fontSize: 15),
                    focusedBorder: new UnderlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.red,
                          width: 1.0,
                          style: BorderStyle.solid),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 40),
                child: TextFormField(
                  onSaved: (value) => _email = value,
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                  ),
                  decoration: InputDecoration(
                    labelText: "Địa chỉ Email",
                    labelStyle:
                        new TextStyle(color: Colors.black26, fontSize: 15),
                    focusedBorder: new UnderlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.red,
                          width: 1.0,
                          style: BorderStyle.solid),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 40),
                child: TextFormField(
                  onSaved: (value) => _lastName = value,
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                  ),
                  decoration: InputDecoration(
                    labelText: "Họ",
                    labelStyle:
                        new TextStyle(color: Colors.black26, fontSize: 15),
                    focusedBorder: new UnderlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.red,
                          width: 1.0,
                          style: BorderStyle.solid),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 40),
                child: TextFormField(
                  onSaved: (value) => _firstName = value,
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                  ),
                  decoration: InputDecoration(
                    labelText: "Tên",
                    labelStyle:
                        new TextStyle(color: Colors.black26, fontSize: 15),
                    focusedBorder: new UnderlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.red,
                          width: 1.0,
                          style: BorderStyle.solid),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 40),
                child: TextFormField(
                  onSaved: (value) => _phone = value,
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                  ),
                  decoration: InputDecoration(
                    labelText: "Số điện thoại",
                    labelStyle:
                        new TextStyle(color: Colors.black26, fontSize: 15),
                    focusedBorder: new UnderlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.red,
                          width: 1.0,
                          style: BorderStyle.solid),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 40),
                child: TextFormField(
                  onSaved: (value) => _address = value,
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                  ),
                  decoration: InputDecoration(
                    labelText: "Địa chỉ",
                    labelStyle:
                        new TextStyle(color: Colors.black26, fontSize: 15),
                    focusedBorder: new UnderlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.red,
                          width: 1.0,
                          style: BorderStyle.solid),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                child: SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: RaisedButton(
                    color: Colors.red,
                    onPressed: () {
                      setState(() {
                        onRegisterClicked(context);
                      });
                    },
                    child: Text(
                      "Đăng ký",
                      style: TextStyle(color: Colors.white, fontSize: 18),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void onToggleShowPass() {
    setState(() {
      _showPass = !_showPass;
    });
  }

  void onRegisterClicked(context) {
    final form = _formKey.currentState;
    form.save();

    if (form.validate()) {
      form.save();
      print("ok");
    } else {
      setState(() {
        _autoValidate = true;
      });
    }
  }
}
