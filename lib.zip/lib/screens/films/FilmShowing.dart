import 'dart:convert';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:cinema_x/models/user.dart';
import 'package:cinema_x/models/Movie.dart';
import 'package:cinema_x/screens/details/MovieDetails.dart';
import 'package:flutter/material.dart';
import 'package:cinema_x/utils/menu_drawer.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FilmShowing extends StatefulWidget {
  @override
  _ListFilms createState() => _ListFilms();
}

class _ListFilms extends State<FilmShowing> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  int _current = 0;
  Future<List<Movie>> _showingMovies;
  List imgList;
  List nameList;
  List versionList;
  List<T> map<T>(List list, Function handler) {
    List<T> result = [];
    for (var i = 0; i < list.length; i++) {
      result.add(handler(i, list[i]));
    }
    return result;
  }

  @override
  void initState() {
    _showingMovies = fetchShowingMovies();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      endDrawer: MenuBar(),
      key: _scaffoldKey,
      appBar: new AppBar(
        title: new Text('Chọn phim của bạn'),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.menu),
            onPressed: () => _scaffoldKey.currentState.openEndDrawer(),
          ),
        ],
        backgroundColor: Colors.red,
      ),
      //  resizeToAvoidBottomPadding: false,
      body: FutureBuilder(
        future: _showingMovies,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return Container(
              child: ListView(
                children: (snapshot.data as List<Movie>).map((data) {
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => MovieDetailsPage(
                            movie: data,
                          ),
                        ),
                      );
                    },
                    child: Card(
                      child: Row(
                        children: <Widget>[
                          Image(
                            image: NetworkImage(data.imageUrl),
                            height: 100,
                          ),
                          Container(
                            margin: EdgeInsets.only(left: 10),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                AutoSizeText(
                                  data.name,
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                  maxLines: 2,
                                ),
                                Text(
                                  DateFormat("dd/MM/yyyy").format(
                                    DateTime.parse(data.premieredDay),
                                  ),
                                ),
                                Text(data.duration.toString() + " phút"),
                                Row(
                                  children: <Widget>[
                                    AutoSizeText(
                                      data.versionCode,
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.red),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }

  pushToSave() {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text("Login thành công"),
      ),
    );
    //print("Hello");
  }

  Widget test(BuildContext context, dynamic item) {
    return Container();
  }

  // void onSignInClicked(BuildContext context) async {
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   final form = _formKey.currentState;
  //   form.save();

  //   // Validate will return true if is valid, or false if invalid.
  //   if (form.validate()) {
  //     String api =
  //         'http://testapi.chieuphimquocgia.com.vn/api/LoginApp?Email=${Uri.encodeFull(_userId)}&Password=$_password';
  //     Map<String, String> headers = {
  //       'Content-type': 'application/json',
  //       'Accept': 'application/json'
  //     };
  //     var body = {"Email": Uri.encodeFull(_userId), "Password": _password};
  //     // var response = await http.post(api);
  //     var response = await http.post(Uri.parse(api),
  //         headers: headers, body: json.encode(body));
  //     print(response.body);
  //     if (response.statusCode == 200) {
  //       Map parsed = json.decode(response.body);
  //       setState(() {
  //         statusCode = parsed["StatusCode"] as int;
  //         print(statusCode);
  //       });
  //       if (statusCode == 30) {
  //         User user = User.fromJson(parsed["User"]);
  //         setUserInfo(prefs, user);
  //         // Navigator.push(
  //         //     context, MaterialPageRoute(builder: (context) => HomeScreen()));
  //         Navigator.pop(context);
  //       }
  //     }
  //   }
  // }

  void setUserInfo(SharedPreferences prefs, User user) {
    prefs.setBool('isLoggedIn', true);
    prefs.setString("fullName", user.fullName);
    prefs.setString("firstName", user.firstName);
    prefs.setString("lastName", user.lastName);
    prefs.setInt("customerId", user.id);
    prefs.setDouble("pointReward", user.pointReward);
    prefs.setDouble("pointCard", user.pointCard);
    prefs.setString("email", user.email);
    prefs.setString("phone", user.phoneNumber);
  }

  void logOut(SharedPreferences prefs) async {
    await prefs.clear();
  }
}
